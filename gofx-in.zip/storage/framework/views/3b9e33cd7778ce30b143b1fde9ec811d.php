

<?php $__env->startSection('title', $article->title.' — Articles — GOFX'); ?>
<?php $__env->startSection('content'); ?>
<section class="py-20">
  <div class="max-w-4xl mx-auto px-6">
    <article class="bg-slate-900/40 rounded-2xl p-10">
      <h1 class="text-3xl md:text-4xl font-extrabold text-white mb-4"><?php echo e($article->title); ?></h1>
      <div class="text-slate-400 mb-6">By <?php echo e($article->author ?? 'GOFX'); ?> • <?php echo e($article->published_at ? $article->published_at->format('F j, Y') : ''); ?></div>

      <div class="prose prose-invert max-w-none text-slate-100">
        <?php echo $article->body; ?>

      </div>
    </article>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\work\rits\gofx.in\gofx-in\resources\views/articles/show.blade.php ENDPATH**/ ?>