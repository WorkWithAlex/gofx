
<?php $__env->startSection('title','Library — GOFX'); ?>
<?php $__env->startSection('content'); ?>
<section class="py-20">
  <div class="max-w-6xl mx-auto px-6">
    <h1 class="text-4xl font-extrabold text-white mb-6">Library</h1>

    <div class="grid md:grid-cols-3 gap-6">
      <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $it): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="bg-slate-800/30 p-6 rounded-2xl">
          <h3 class="text-white font-semibold mb-2"><?php echo e($it->title); ?></h3>
          <p class="text-slate-300 mb-4"><?php echo e($it->summary); ?></p>
          <?php if($it->file_path): ?>
            <a href="<?php echo e(asset($it->file_path)); ?>" target="_blank" class="text-slate-200 font-semibold">Download →</a>
          <?php elseif($it->url): ?>
            <a href="<?php echo e($it->url); ?>" target="_blank" class="text-slate-200 font-semibold">Open →</a>
          <?php endif; ?>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="mt-8"><?php echo e($items->links()); ?></div>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\work\rits\gofx.in\gofx-in\resources\views/library/index.blade.php ENDPATH**/ ?>