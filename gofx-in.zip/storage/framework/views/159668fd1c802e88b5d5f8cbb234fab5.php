

<?php $__env->startSection('title', 'Guides — Learn Hub — GOFX'); ?>

<?php $__env->startSection('content'); ?>
<section class="py-20">
  <div class="max-w-6xl mx-auto px-6">
    <div class="mb-8">
      <h1 class="text-4xl font-extrabold text-white">Trading Guides</h1>
      <p class="text-slate-300 mt-2 max-w-2xl">In-depth how-to guides and structured lessons to help you build a strong trading foundation.</p>
    </div>

    <?php if($guides->count()): ?>
      <div class="grid md:grid-cols-3 gap-6">
        <?php $__currentLoopData = $guides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <article class="bg-slate-800/30 rounded-2xl p-6">
            <h3 class="text-white text-xl font-semibold mb-2">
              <a href="<?php echo e(route('guides.show', $g->slug)); ?>"><?php echo e($g->title); ?></a>
            </h3>

            <p class="text-slate-300 mb-4"><?php echo e($g->excerpt); ?></p>

            <div class="flex items-center justify-between">
              <div class="text-slate-400 text-sm">By <?php echo e($g->author ?? 'GOFX'); ?></div>
              <a href="<?php echo e(route('guides.show', $g->slug)); ?>" class="text-sm font-semibold text-slate-200">Read →</a>
            </div>
          </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>

      <div class="mt-8">
        <?php echo e($guides->links()); ?>

      </div>
    <?php else: ?>
      <div class="bg-slate-900/40 rounded-2xl p-8 text-slate-300">
        No guides found yet. Check back soon.
      </div>
    <?php endif; ?>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\work\rits\gofx.in\gofx-in\resources\views/guides/index.blade.php ENDPATH**/ ?>