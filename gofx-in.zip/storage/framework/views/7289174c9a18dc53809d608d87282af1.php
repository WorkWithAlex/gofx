

<?php $__env->startSection('title','Payment Failed — GOFX'); ?>

<?php $__env->startSection('content'); ?>
<div class="pt-24 pb-16">
  <div class="max-w-3xl mx-auto px-6">
    <div class="bg-black/40 p-8 rounded-lg text-center">
      <h1 class="text-3xl font-bold text-red-400">Payment failed or was cancelled</h1>

      <?php if(!empty($message)): ?>
        <p class="mt-4 text-slate-300"><?php echo $message; ?></p>
      <?php else: ?>
        <p class="mt-4 text-slate-300">If you were charged, please contact support at <strong><?php echo e(env('CONTACT_EMAIL')); ?></strong> with your transaction details.</p>
      <?php endif; ?>

      <?php if(!empty($payload)): ?>
        <div class="mt-4 text-left bg-black/30 p-3 rounded text-sm text-slate-300">
          <strong>Debug info (PayU):</strong>
          <pre class="whitespace-pre-wrap text-xs"><?php echo e(json_encode($payload, JSON_PRETTY_PRINT)); ?></pre>
        </div>
      <?php endif; ?>

      <div class="mt-6">
        <a href="<?php echo e(url()->previous()); ?>" class="px-6 py-3 rounded-md border border-white/10">Try Again</a>
        <a href="<?php echo e(url('/contact')); ?>" class="ml-3 px-6 py-3 rounded-md border border-white/10">Contact Support</a>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\work\rits\gofx.in\gofx-in\resources\views/checkout/failure.blade.php ENDPATH**/ ?>