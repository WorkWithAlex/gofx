

<?php $__env->startSection('title', ($guide->title ?? 'Guide') . ' — GOFX'); ?>

<?php $__env->startSection('content'); ?>
<section class="py-20">
  <div class="max-w-4xl mx-auto px-6">
    <article class="bg-slate-900/40 rounded-2xl p-10">
      <div class="mb-4 text-slate-400 text-sm">
        <a href="<?php echo e(route('guides.index')); ?>" class="underline">Guides</a> &middot;
        <span class="ml-2"><?php echo e($guide->published_at ? $guide->published_at->format('F j, Y') : ''); ?></span>
      </div>

      <h1 class="text-3xl md:text-4xl font-extrabold text-white mb-4"><?php echo e($guide->title); ?></h1>
      <div class="text-slate-300 mb-6"><?php echo e($guide->excerpt); ?></div>

      <div class="prose prose-invert max-w-none text-slate-100">
        <?php echo $guide->body ?? '<p>No content available yet.</p>'; ?>

      </div>
    </article>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\work\rits\gofx.in\gofx-in\resources\views/guides/show.blade.php ENDPATH**/ ?>