

<?php $__env->startSection('title', 'Courses — GOFX'); ?>

<?php $__env->startSection('content'); ?>
<div class="pt-24 pb-16">
  <div class="max-w-5xl mx-auto px-6">
    <h1 class="text-3xl font-bold">All Courses</h1>
    <div class="mt-6 grid md:grid-cols-2 gap-6 ">
      <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class='block p-5 bg-black/40 rounded-2xl border border-white/5 hover:scale-[1.01] transition glass-neon-blue'>
          <img src="<?php echo e($c['thumbnail']); ?>" alt="<?php echo e($c['title']); ?> Thumbnail" class="w-full mb-6 h-40 object-cover rounded-md border border-white/10">
          <h3 class="text-xl font-semibold text-white"><?php echo e($c['title']); ?></h3>
          <p class="text-slate-300 mt-2">Open the course page to view curriculum and enroll.</p>
          <a class="mt-4 inline-block" href="<?php echo e(route('courses.show', $c['slug'])); ?>">
            <button class="inline-block px-6 py-3 font-semibold rounded-md" style="background:linear-gradient(90deg,var(--accent2),var(--accent1)); color:#000;">
              View Details
            </button>
          </a>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\work\rits\gofx.in\gofx-in\resources\views/courses/index.blade.php ENDPATH**/ ?>