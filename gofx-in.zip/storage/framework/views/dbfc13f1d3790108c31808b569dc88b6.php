

<?php $__env->startSection('title', 'Articles — Learn Hub — GOFX'); ?>

<?php $__env->startSection('content'); ?>
<section class="py-20">
  <div class="max-w-6xl mx-auto px-6">
    <h1 class="text-4xl font-extrabold text-white mb-6">Articles</h1>

    <div class="grid md:grid-cols-3 gap-6">
      <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <article class="bg-slate-800/30 rounded-2xl p-6">
          <h3 class="text-white text-xl font-semibold mb-2">
            <a href="<?php echo e(route('articles.show', $a->slug)); ?>"><?php echo e($a->title); ?></a>
          </h3>
          <p class="text-slate-300 mb-4"><?php echo e($a->excerpt); ?></p>
          <div class="flex items-center justify-between">
            <div class="text-slate-400 text-sm">By <?php echo e($a->author ?? 'GOFX'); ?> • <?php echo e($a->published_at ? $a->published_at->diffForHumans() : ''); ?></div>
            <a href="<?php echo e(route('articles.show', $a->slug)); ?>" class="text-sm font-semibold text-slate-200">Read →</a>
          </div>
        </article>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="mt-8">
      <?php echo e($articles->links()); ?>

    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\work\rits\gofx.in\gofx-in\resources\views/strategies/index.blade.php ENDPATH**/ ?>