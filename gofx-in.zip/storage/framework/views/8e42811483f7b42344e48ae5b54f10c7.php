
<?php $__env->startSection('title','Tools & Calculators — GOFX'); ?>
<?php $__env->startSection('content'); ?>
<section class="py-20">
  <div class="max-w-6xl mx-auto px-6">
    <h1 class="text-4xl font-extrabold text-white mb-6">Tools & Calculators</h1>

    <div class="grid md:grid-cols-3 gap-6">
      <?php $__currentLoopData = $tools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="bg-slate-800/30 p-6 rounded-2xl">
          <h3 class="text-white font-semibold mb-2"><a href="<?php echo e(route('tools.show', $t->slug)); ?>"><?php echo e($t->title); ?></a></h3>
          <p class="text-slate-300 mb-4"><?php echo e($t->summary); ?></p>
          <a href="<?php echo e(route('tools.show', $t->slug)); ?>" class="text-slate-200 font-semibold">Open tool →</a>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\work\rits\gofx.in\gofx-in\resources\views/tools/index.blade.php ENDPATH**/ ?>