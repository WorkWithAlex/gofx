@extends('layouts.app')

@section('title', 'Contact — GOFX | Gold & Bitcoin Forex')

@section('content')

{{-- CONTACT HERO --}}
@include('partials.contact.hero')

{{-- CONTACT FORM --}}
@include('partials.contact.form')

@endsection
